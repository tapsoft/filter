# capture

Intercepts packets for the specified network interface and saves those into the PCAP file which can be opened and analyzed with WireShark.



