# sni_inspector

Intercepts network packets and extracts SNI from HTTPS packets and Host from HTTP packets.



