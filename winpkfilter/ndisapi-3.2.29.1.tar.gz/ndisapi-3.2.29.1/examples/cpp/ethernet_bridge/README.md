# ethernet_bridge

Implements bridging local wired and wireless network adapters. More information https://www.ntkernel.com/bridging-networks-with-windows-packet-filter/



