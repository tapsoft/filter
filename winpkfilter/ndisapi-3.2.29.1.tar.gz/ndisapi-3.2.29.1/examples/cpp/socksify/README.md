# socksify

Redirect selected TCP connections through a SOCKS5 proxy. 




