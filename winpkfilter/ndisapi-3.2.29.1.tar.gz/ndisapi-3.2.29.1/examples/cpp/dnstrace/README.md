# dnstrace

Intercepts DNS responses for the specified network interface and decodes their content to the console. This sample also demonstares how to link NDISAPI statically and dynamically (using corresponding congigurations).



