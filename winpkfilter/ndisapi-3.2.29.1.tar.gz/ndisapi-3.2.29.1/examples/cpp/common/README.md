# common

Utility C++ classes used across native C++ samples.
