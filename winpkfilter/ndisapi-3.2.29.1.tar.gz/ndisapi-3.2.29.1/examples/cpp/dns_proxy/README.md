# dns_proxy

Redirects DNS protocol through the transparent UDP proxy.