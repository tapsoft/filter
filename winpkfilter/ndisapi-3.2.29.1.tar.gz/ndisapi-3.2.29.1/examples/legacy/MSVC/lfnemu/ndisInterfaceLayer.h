#ifndef _NDISINTERFACELAYER_H
#define _NDISINTERFACELAYER_H

#include "Common.h"

// NDIS Lower Layer variables and functions
void ndisBottomLayer(PETH_REQUEST pRequest);
void ndisTopLayer(PETH_REQUEST pRequest);

#endif //_NDISINTERFACELAYER_H