#ifndef _FINALIZATION_H
#define _FINALIZATION_H

#include "Common.h"
#include "PacketDelayerLayer.h"
#include "PacketDropperLayer.h"

void ReleaseHandles();
void ReleaseInterface();

#endif //_FINALIZATION_H